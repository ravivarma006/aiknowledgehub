/* global React, ReactDOM */
// Root app: routing, bookmarks, AI assistant sheet, bottom nav

const { useState, useEffect, useCallback } = React;

function BottomNav({ current, onNav, onAI }) {
  return (
    <nav className="bottom-nav">
      <button className={`nav-item ${current === 'home' ? 'active' : ''}`} onClick={() => onNav({ route: 'home' })}>
        <span className="indicator" />
        <Icon name="home" size={20} />
        <span>Home</span>
      </button>
      <button className={`nav-item ${current === 'category' ? 'active' : ''}`} onClick={() => onNav({ route: 'category' })}>
        <span className="indicator" />
        <Icon name="grid" size={20} />
        <span>Browse</span>
      </button>
      <button className="nav-orb" onClick={() => onAI()}>
        <Icon name="sparkle" size={22} stroke={2.2} />
      </button>
      <button className={`nav-item ${current === 'saved' ? 'active' : ''}`} onClick={() => onNav({ route: 'saved' })}>
        <span className="indicator" />
        <Icon name="bookmark" size={20} />
        <span>Saved</span>
      </button>
      <button className={`nav-item ${current === 'profile' ? 'active' : ''}`} onClick={() => onNav({ route: 'profile' })}>
        <span className="indicator" />
        <Icon name="user" size={20} />
        <span>Profile</span>
      </button>
    </nav>
  );
}

// ── AI Assistant sheet ──────────────────────────────
function AISheet({ open, onClose, seed }) {
  const [msgs, setMsgs] = useState([
    { role: 'ai', text: "Hi Prasanna — I'm Nexus AI. Ask me anything about the 75+ tools in your hub, or tell me what you're building." }
  ]);
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState('');
  const bodyRef = React.useRef(null);

  useEffect(() => {
    if (open && seed && seed.trim()) {
      send(seed);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, seed]);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [msgs, typing]);

  const send = (text) => {
    if (!text.trim()) return;
    setMsgs(m => [...m, { role: 'me', text }]);
    setInput('');
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs(m => [...m, suggestReply(text)]);
    }, 900 + Math.random() * 500);
  };

  return (
    <>
      <div className={`ai-backdrop ${open ? 'open' : ''}`} onClick={onClose} />
      <div className={`ai-sheet ${open ? 'open' : ''}`} role="dialog" aria-label="AI Assistant">
        <div className="ai-sheet-grip" />
        <div className="ai-sheet-head">
          <div className="ai-avatar">✶</div>
          <div style={{ flex: 1 }}>
            <h3>Nexus AI</h3>
            <div className="sub">Always-on · Haiku 4.5</div>
          </div>
          <button className="iconbtn" onClick={onClose}><Icon name="x" size={18} /></button>
        </div>

        <div className="ai-body" ref={bodyRef}>
          {msgs.map((m, i) => (
            <div key={i} className={`msg ${m.role}`}>
              <div className="bubble">
                {m.text}
                {m.chips && (
                  <div className="chip-row">
                    {m.chips.map(c => <span key={c} className="chip">{c}</span>)}
                  </div>
                )}
              </div>
            </div>
          ))}
          {typing && (
            <div className="msg ai">
              <div className="bubble">
                <span className="typing"><span/><span/><span/></span>
              </div>
            </div>
          )}
          {msgs.length === 1 && !typing && (
            <div className="chip-row" style={{ marginTop: 8 }}>
              {['Best AI coding stack?', 'How to use MCP?', 'Compare Supabase vs Firebase', 'RAG with Azure AI Search'].map(s => (
                <span key={s} className="chip" style={{ cursor: 'pointer' }} onClick={() => send(s)}>{s}</span>
              ))}
            </div>
          )}
        </div>

        <div className="ai-input-wrap">
          <form className="ai-input" onSubmit={(e) => { e.preventDefault(); send(input); }}>
            <Icon name="sparkle" size={16} />
            <input
              placeholder="Ask Nexus AI…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit" className="ai-send" aria-label="Send">
              <Icon name="send" size={16} stroke={2.2} />
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

function suggestReply(q) {
  const low = q.toLowerCase();
  // keyword routing for demo replies
  if (/mcp/.test(low)) {
    return { role: 'ai', text: "MCP (Model Context Protocol) lets AI agents talk to real tools. Start with the base server, then add domain servers like Postgres MCP, GitHub MCP, or Azure MCP.", chips: ['MCP Tools','GitHub MCP','Postgres MCP','Composio'] };
  }
  if (/rag|vector|search/.test(low)) {
    return { role: 'ai', text: "For RAG, pair Firecrawl (for clean markdown ingest) with Azure AI Search or Supabase pgvector. Vercel AI SDK makes the streaming UI trivial.", chips: ['Firecrawl','Azure AI Search','Supabase','Vercel AI SDK'] };
  }
  if (/supabase|firebase/.test(low)) {
    return { role: 'ai', text: "Supabase = open-source Postgres + Auth + pgvector. Firebase = battle-tested realtime + generous free tier. Pick Supabase for SQL-first apps, Firebase for fast mobile.", chips: ['Supabase','Firebase'] };
  }
  if (/stack|best|recommend/.test(low)) {
    return { role: 'ai', text: "A solid 2026 stack: Next.js + Vercel AI SDK on Vercel, Supabase for data & auth, Motion for animations, Cursor or Claude Code for dev velocity.", chips: ['Next.js','Vercel AI SDK','Supabase','Cursor','Motion'] };
  }
  if (/mvp|prototype|fast/.test(low)) {
    return { role: 'ai', text: "Fastest path to an MVP: Lovable for the prompt → app scaffold, Supabase for data, Vercel to deploy. Iterate in Cursor once you outgrow the generator.", chips: ['Lovable','Supabase','Vercel','Cursor'] };
  }
  return { role: 'ai', text: "Good question. I'd look at the tools tagged with that keyword in the hub — tap any of these to jump to its detail page:", chips: window.TOOLS.slice(0, 4).map(t => t.name) };
}

// ── Saved page (simple) ──────────────────────────────
function SavedPage({ nav, bookmarks, toggleBookmark }) {
  const saved = window.TOOLS.filter(t => bookmarks.has(t.id));
  return (
    <div className="page">
      <div className="screen-bg" />
      <div className="topbar">
        <div className="topbar-title">Saved</div>
        <button className="iconbtn"><Icon name="filter" size={18} /></button>
      </div>
      <div className="page-inner">
        <div className="eyebrow">Your collection</div>
        <div className="h-display" style={{ fontSize: 28, marginTop: 4 }}>
          {saved.length} <span className="grad-text">bookmarks</span>
        </div>
        <div className="muted" style={{ fontSize: 13, marginTop: 6, marginBottom: 16 }}>
          Tap the bookmark icon on any tool to add it here.
        </div>
        <div className="stagger">
          {saved.length === 0 ? (
            <div className="glass" style={{ padding: 24, textAlign: 'center' }}>
              <div style={{ fontSize: 36, marginBottom: 10 }}>✶</div>
              <div style={{ fontFamily: 'var(--ff-display)', fontWeight: 600, marginBottom: 4 }}>Nothing saved yet</div>
              <div className="muted" style={{ fontSize: 13 }}>Start bookmarking — try tapping the ribbon on Cursor or Motion.</div>
            </div>
          ) : saved.map(t => (
            <ToolCard key={t.id} tool={t}
              onOpen={(id) => nav({ route: 'detail', toolId: id })}
              bookmarked={true}
              onBookmark={() => toggleBookmark(t.id)} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Profile page (simple) ──────────────────────────────
function ProfilePage({ nav }) {
  return (
    <div className="page">
      <div className="screen-bg" />
      <div className="topbar">
        <div className="topbar-title">Profile</div>
        <button className="iconbtn"><Icon name="share" size={18} /></button>
      </div>
      <div className="page-inner stagger">
        <div className="hero-card glass-rim" style={{ textAlign: 'center' }}>
          <div className="hc-aura" style={{ background: '#b68cff' }} />
          <div style={{ width: 80, height: 80, borderRadius: '50%', margin: '6px auto 12px', background: 'var(--grad-primary)', display: 'grid', placeItems: 'center', fontFamily: 'var(--ff-display)', fontWeight: 700, fontSize: 28, color: '#0a0520', boxShadow: '0 0 40px rgba(182,140,255,.4)' }}>PC</div>
          <div className="h-display" style={{ fontSize: 22 }}>Prasanna Cantulum</div>
          <div className="muted" style={{ fontSize: 13, marginTop: 4 }}>prasanna.cantulum@gmail.com</div>
          <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: 20, padding: '14px 0 4px', borderTop: '1px solid var(--line)' }}>
            {[['75','Explored'],['12','Saved'],['43','Days']].map(([n,l]) => (
              <div key={l}>
                <div style={{ fontFamily: 'var(--ff-display)', fontWeight: 700, fontSize: 20 }} className="grad-text">{n}</div>
                <div className="eyebrow" style={{ fontSize: 10 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="accordion mt-16">
          {['Notifications','Appearance','Privacy','Help & Feedback','About Nexus'].map(s => (
            <div key={s} className="acc-item">
              <button className="acc-head">
                <span>{s}</span>
                <Icon name="chev-r" size={16} className="acc-chev" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── App Shell ──────────────────────────────
function App() {
  const [state, setState] = useState({ route: 'home' });
  const [history, setHistory] = useState([]);
  const [bookmarks, setBookmarks] = useState(new Set(['motion','cursor','nextjs']));
  const [aiOpen, setAiOpen] = useState(false);
  const [aiSeed, setAiSeed] = useState('');

  const nav = useCallback((next) => {
    setHistory(h => [...h, state]);
    setState(next);
    // reset scroll
    requestAnimationFrame(() => {
      const p = document.querySelector('.page');
      if (p) p.scrollTop = 0;
    });
  }, [state]);
  nav.back = () => {
    if (history.length > 0) {
      const prev = history[history.length - 1];
      setHistory(h => h.slice(0, -1));
      setState(prev);
    } else {
      setState({ route: 'home' });
    }
  };

  const toggleBookmark = (id) => {
    setBookmarks(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const openAI = (seed = '') => {
    setAiSeed(seed);
    setAiOpen(true);
  };

  let page = null;
  switch (state.route) {
    case 'category':
      page = <CategoryPage key={state.catId || 'all'} nav={nav} catId={state.catId} bookmarks={bookmarks} toggleBookmark={toggleBookmark} />; break;
    case 'detail':
      page = <DetailPage key={state.toolId} nav={nav} toolId={state.toolId} bookmarks={bookmarks} toggleBookmark={toggleBookmark} openAI={openAI} />; break;
    case 'saved':
      page = <SavedPage nav={nav} bookmarks={bookmarks} toggleBookmark={toggleBookmark} />; break;
    case 'profile':
      page = <ProfilePage nav={nav} />; break;
    case 'home':
    default:
      page = <HomePage nav={nav} bookmarks={bookmarks} toggleBookmark={toggleBookmark} openAI={openAI} />;
  }

  return (
    <>
      {page}
      <BottomNav
        current={state.route === 'detail' ? 'home' : state.route}
        onNav={nav}
        onAI={() => openAI('')}
      />
      <AISheet open={aiOpen} onClose={() => setAiOpen(false)} seed={aiSeed} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById('app')).render(<App />);
